import json
import yfinance as yf
import boto3
import os


def lambda_handler(event, context):
    if (
        "queryStringParameters" not in event
        or "ticker" not in event["queryStringParameters"]
    ):
        return {
            "isBase64Encoded": False,
            "statusCode": 404,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
            },
            "body": "No ticker is provided",
        }

    ticker = event["queryStringParameters"]["ticker"]
    ticker_data = yf.Ticker(ticker)

    all_news = ticker_data.get_news()
    summary_list = []
    for news in all_news:
        if "summary" in news["content"]:
            summary_list.append(news["content"]["summary"])

    comprehend = boto3.client("comprehend", region_name="us-east-2")
    response = comprehend.batch_detect_sentiment(
        TextList=summary_list, LanguageCode="en"
    )

    return {
        "isBase64Encoded": False,
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
        },
        "body": json.dumps(
            {"sentiment_response": response["ResultList"], "news": all_news}
        ),
    }


sns = boto3.client("sns", region_name="us-east-2")


def sns_event_function(event, context):
    TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]
    try:
        json_body = json.loads(event["body"])
        email = json_body.get("email")  # gets email from json request

        if not email:
            return {
                "statusCode": 400,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                    "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
                },
                "body": json.dumps({"message": "email is required for sign up"}),
            }

        response = sns.subscribe(  # sends subscription request to sns using user email
            TopicArn=TOPIC_ARN, Protocol="email", Endpoint=email
        )

        return {  # Response if successful, function should send a confirmation email to user
            "isBase64Encoded": False,
            "statusCode": 200,
            "body": json.dumps(
                {
                    "message": "you have subscribed to recieve notifcations. Check for a confirmation email in your inbox."
                }
            ),
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
            },
        }

    except Exception as error:
        return {
            "isBase64Encoded": False,
            "statusCode": 400,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
            },
            "body": json.dumps({"message": f"An error has occurred\n{error}"}),
        }


def sns_send_data(event, context):
    TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]
    try:
        json_body = json.loads(event["body"])

        ticker = json_body.get("ticker")
        sentiment = json_body.get("sentiment")
        scores = json_body.get("sentimentScore")

        stock_data = json_body.get("stock_data")  # gets email from json request

        if not stock_data:
            return {
                "statusCode": 400,
                "headers": {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                    "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
                },
                "body": json.dumps({"message": "email is required for sign up"}),
            }

        response = sns.publish(  # sends subscription request to sns using user email
            TopicArn=TOPIC_ARN,
            Message=(
                f"Stock Update for {ticker}\n",
                f"Overall Stock Sentiment {sentiment}\n",
                f"Scores: \n",
                f"Positive: {scores.get('positive')}\n",
                f"Negative: {scores.get('negative')}\n",
                f"Mixed: {scores.get('mixed')}\n",
                f"Neutral: {scores.get('neutral')}\n",
            ),
            Subject=f"Stock Alert: {ticker}",
        )

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
            },
            "body": json.dumps({"message": "Stock alert email sent."}),
        }

    except Exception as error:
        return {
            "statusCode": 400,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
                "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS",
            },
            "body": json.dumps({"message": f"An error has occurred\n{error}"}),
        }
